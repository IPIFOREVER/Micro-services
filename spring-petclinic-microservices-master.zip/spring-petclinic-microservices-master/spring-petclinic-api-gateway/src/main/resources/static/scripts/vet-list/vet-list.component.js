'use strict';

angular.module('vetList')
    .component('vetList', {
        templateUrl: 'scripts/vet-list/vet-list.template.html',
        controller: 'VetListController'
    });
